package foo
func Foo() {}
