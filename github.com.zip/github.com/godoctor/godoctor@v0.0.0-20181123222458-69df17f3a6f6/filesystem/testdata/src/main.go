package main

import "foo"
import "bar"

func main() {
	foo.Foo()
	bar.Bar()
}
