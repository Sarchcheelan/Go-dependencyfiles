package bar
func Bar() {}
