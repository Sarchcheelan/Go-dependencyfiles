package main

func main() {
	foo()
}

func foo() {
}

//<<<<<debug,7,1,7,1,showcfg,pass
