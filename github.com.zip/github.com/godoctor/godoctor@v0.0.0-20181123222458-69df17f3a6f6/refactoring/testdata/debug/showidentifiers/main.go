package main //<<<<<debug,1,1,1,1,showidentifiers,pass

type S struct {}
func (s *S) String() string { return "" }

func foo() string { return (&S{}).String() }
